<!DOCTYPE html>
<html>
    <head>
        <title>Hovedside</title>
        <link rel="stylesheet" href="ForsideStyle.css">
    </head>
    <body>
        <ul class="navbar">
            <li class="navbar-item"><a class="active" href="../../index.php">Forside</a></li>
            <li class="navbar-item"><a href="../index.php">tilbake</a></li>
        </ul>

        <p><a href="1/co.php">Oppgave 5</a></p>
        <p><a href="2/loop.php">Oppgave 6</a></p>
        <p><a href="3/input.php">Oppgave 8</a></p>
    </body>
</html>